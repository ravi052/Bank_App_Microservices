package com.bankingapp.models;

import java.util.List;

public class CustomerDto {

	private List<Customer> list;

	public List<Customer> getList() {
		return list;
	}

	public void setList(List<Customer> list) {
		this.list = list;
	}

	@Override
	public String toString() {
		return String.format("CustomerDto [list=%s]", list);
	}

	public CustomerDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	}
