package com.bankingapp.models;

import java.util.List;


public class AccountDTO {
	private List<Account> list;

	public List<Account> getList() {
		return list;
	}

	public void setList(List<Account> list) {
		this.list = list;
	}

	@Override
	public String toString() {
		return String.format("AccountDTO [list=%s]", list);
	}

	public AccountDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

}
