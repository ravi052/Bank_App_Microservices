package com.banking.customerservice;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.banking.customerservice.dao.CustomerDao;
import com.banking.customerservice.exception.NoRecordsException;
import com.banking.customerservice.model.Customer;
import com.banking.customerservice.service.CustomerService;

@SpringBootTest
class CustomerServiceApplicationTests {
	@Autowired
	CustomerService cusService;
	
	@MockBean
     CustomerDao dao;
	@Test
	void contextLoads() {
	}
	
	
	@Test
	public void testAddCustomer() {
		Customer cus = new Customer(141, "ravi", "ravi@gmail.com", 9876543, 4335567, "jharkhand", "pune", "29-07-2001");
	
		Mockito.when(dao.save(cus)).thenReturn(cus);
		boolean msg = cusService.addCustomer(cus);
		assertEquals(true, msg);
	}
	
	
	@Test
	public void testUpdateCustomer() {
		Customer customer = new Customer(121, "ravi_prakash", "ravi@gmail.com", 456783, 34567, "bihar", "aundh", "19-09-2000");
		Mockito.when(dao.save(customer)).thenReturn(customer);
		boolean msg = cusService.updateCustomer(customer);
		assertEquals(true, msg);
	}

	@Test
	public void testDeleteCustomer() throws NoRecordsException {
		
		int customerId = 1;
        Customer customer = new Customer();
        Mockito.when(dao.findById(customerId)).thenReturn(Optional.of(customer));

        boolean res = cusService.deleteCustomer(customerId);
        System.out.println(res);

		assertEquals(true, res);
	}

}
