package com.banking.accountservice.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.banking.accountservice.dao.AccountDao;
import com.banking.accountservice.exception.AccountNotFoundException;
import com.banking.accountservice.exception.NoRecordsException;
import com.banking.accountservice.exception.NotEnoughBalanceException;
import com.banking.accountservice.model.Account;



@Service
@Transactional
public class AccountService {

	@Autowired
	private AccountDao dao;

	public boolean addAccount(Account acc) {
		Account acc1 = dao.save(acc);
		if (acc1 != null)
			return true;
		else
			return false;
	}

	public boolean updateAccount(Account acc) {
		Account acc1 = dao.save(acc);
		if (acc1 != null)
			return true;
		else
			return false;
	}

	public List<Account> getAllAccount() {
		List<Account> list = dao.findAll();
		if (list.isEmpty()) {
			throw new NoRecordsException("No records found");
		} else {
			return list;
		}
	}

	public boolean deleteAccount(long accNum) {
		
		Optional<Account> account = dao.findById(accNum);
		Account acc = account.get();
		if (acc != null) {
			dao.deleteById(accNum);
			return true;
		} else {
			throw new NoRecordsException("No record to delete");
		}
		
	}

	public boolean deleteAll() {
		dao.deleteAll();
		return true;
	}

	public boolean depositAccount(long accNumber, double amount)throws AccountNotFoundException {
		// TODO Auto-generated method stub
		Optional<Account> optional = dao.findById(accNumber);
		if (optional.isPresent()) {
			dao.depositAccount(accNumber, amount);
			return true;
		} else {
			throw new AccountNotFoundException("Account number is wrong !!!");
		}
	}
	
	
	
	public boolean withdrawAccount(long accNumber, double amount)
			throws NotEnoughBalanceException, AccountNotFoundException {
		// TODO Auto-generated method stub
		Optional<Account> optional = dao.findById(accNumber);
		if (optional.isPresent()) {
			Account acc = optional.get();
			double currBalance = acc.getAccBalance();
			if (currBalance < amount) {
				throw new NotEnoughBalanceException("Balance is not sufficient !!!");
			} else {
				dao.withdrawAccount(accNumber, amount);
				return true;
				
			}
		} else {
			throw new AccountNotFoundException("Account number is wrong !!!");

		}

	}
	
	
	
	public boolean FundTransferAccount(long fromAccNumber, long toAccNumber, double amount)
			throws NotEnoughBalanceException, AccountNotFoundException {

		Optional<Account> optional = dao.findById(fromAccNumber);
		Optional<Account> optional1 = dao.findById(toAccNumber);
		if (optional.isPresent() & optional1.isPresent()) {
			Account acc = optional.get();
			double currBalance = acc.getAccBalance();
			if (currBalance < amount) {
				throw new NotEnoughBalanceException("Balance is not sufficient !!!");

			} else {
				dao.withdrawAccount(fromAccNumber, amount);
				dao.depositAccount(toAccNumber, amount);
	        return true;
			}
		} else {

			throw new AccountNotFoundException("Account number is wrong !!!");
		}

	}

}
