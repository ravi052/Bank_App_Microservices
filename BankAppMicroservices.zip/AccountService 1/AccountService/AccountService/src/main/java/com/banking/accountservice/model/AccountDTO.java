package com.banking.accountservice.model;

import java.util.List;

import com.banking.accountservice.model.Account;

public class AccountDTO {
	private List<Account> list;

	public List<Account> getList() {
		return list;
	}

	public void setList(List<Account> list) {
		this.list = list;
	}

	@Override
	public String toString() {
		return String.format("AccountDTO [list=%s]", list);
	}

	public AccountDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

}
