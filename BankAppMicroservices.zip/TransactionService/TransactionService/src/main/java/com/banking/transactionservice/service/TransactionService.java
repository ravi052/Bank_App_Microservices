package com.banking.transactionservice.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.banking.transactionservice.dao.TransactionDao;
import com.banking.transactionservice.exception.NoRecordsException;
import com.banking.transactionservice.model.Transaction;



@Service
@Transactional
public class  TransactionService {

	@Autowired
	TransactionDao dao;
	
	public boolean addTransaction(Transaction tran) {
		Transaction transaction = dao.save(tran);
		if (transaction != null)
			return true;
		else
			return false;
	}
	
	public boolean updateTransaction(Transaction tran) {
		Transaction transaction = dao.save(tran);
		if (transaction != null)
			return true;
		else
			return false;
	}
	
	
	public List<Transaction> getAllTransaction() {
		List<Transaction> list = dao.findAll();
		if (list.isEmpty()) {
			throw new NoRecordsException("No records found");
		} else {
			return list;
		}
	}
	
	public boolean deleteTransaction(int tranId) {
		
		Optional<Transaction> tran = dao.findById(tranId);
		Transaction trandb1 = tran.get();
		if (trandb1 != null) {
			dao.deleteById(tranId);
			return true;
		} else {
			throw new NoRecordsException("No record to delete");
		}
	}


	

}
