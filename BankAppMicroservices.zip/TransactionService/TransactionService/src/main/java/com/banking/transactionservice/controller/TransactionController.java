package com.banking.transactionservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.banking.transactionservice.model.Transaction;
import com.banking.transactionservice.model.TransactionDTO;
import com.banking.transactionservice.service.TransactionService;
import com.banking.transactionservice.model.TransactionDTO;

@RestController
public class TransactionController {
	@Autowired
	private TransactionService tranService;

	@PostMapping("/create")
	public ResponseEntity<Object> addTransaction(@RequestBody Transaction tran) // http://localhost:8080/customer/createCustomer
	{
		// return cusService.createCustomer(customer);
		if (tranService.addTransaction(tran)) {
			return new ResponseEntity<Object>(HttpStatus.CREATED);
		} else
			return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
	}
	
	@PutMapping("/update")
	public ResponseEntity<Object> updateTransaction(@RequestBody Transaction tran) {
		if (tranService.updateTransaction(tran)) {
			return new ResponseEntity<Object>(HttpStatus.CREATED);
		} else
			return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
	}
	
	@DeleteMapping("/delete/{tranId}")
	public ResponseEntity<Object> deleteTransaction(@PathVariable("tranId") int tranId) {
		tranService.deleteTransaction(tranId);
		return new ResponseEntity<Object>("Deleted", HttpStatus.NO_CONTENT);
	}
	
	@GetMapping("/transactions")
	public ResponseEntity<TransactionDTO> getAllTransaction() {
		TransactionDTO dto = new TransactionDTO();
		dto.setList(tranService.getAllTransaction());
		return new ResponseEntity<TransactionDTO>(dto, HttpStatus.OK);
	}
}
